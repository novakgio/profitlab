

<h5 class="down_line_yellow">@lang('services.ჩვენი სერვისები')</h5>
<ul>
								<li class="other_service home_icon"><a href="{{url('/services/marketing')}}">@lang('services.მარკეტინგი')</a></li>
								<li class="other_service car_icon"><a href="{{url('/services/branding')}}">@lang('services.ბრენდინგი')</a></li>
								<li class="other_service office_icon"><a href="{{url('/services/peoplerelation')}}">@lang('services.საზოგადოებასთან ურთიერთობა')</a></li>
								<li class="other_service brush_icon"><a href="{{url('/services/socialresponsibility')}}">@lang('services.სოციალური პასუხისმგებლობა')</a></li>
								<li class="other_service track_icon"><a href="{{url('/services/corporatecommunication')}}">@lang('services.კორპორაციული კომუნიკაცია')</a></li>
								<li class="other_service leaf_icon"><a href="{{url('/services/socialmarketing')}}">@lang('services.სოციალური მედია მარკეტინგი')</a></li>
								<li class="other_service socmarketing"><a href="{{url('/services/digitalmarketing')}}">@lang('services.ციფრული მარკეტინგი')</a></li>
								<li class="other_service design"><a href="{{url('/services/design')}}">@lang('services.დიზაინი')</a></li>
							</ul>


					