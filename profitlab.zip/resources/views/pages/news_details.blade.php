@extends('layout.layout')

 <meta property="og:url"           content="{{url('news_details',$news->id)}}" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="{{$news->title}}" />
  <meta property="og:description"   content="{{str_limit($news->body,20)}}"/>
  <meta property="og:image"         content="{{asset('public/images/news/'.$news->picture)}}" />
  <meta proprty="og:image:width"    content="800"/>
  <meta proprty="og:image:height"    content="800"/>
@section('content')
<!--Page Banner Start-->
    <section id="page_banner">
        <div class="banner_overlay">
            <div class="container">
            	<div class="row">
                    <h2 class="banner_title">უფრო ვრცლად</h2>
                    <ul class="page_banner_link">
                         <li><a href="{{url('/')}}">@lang('all.მთავარი')</a>/</li>
       
                        <li><span>@lang('all.უფრო ვრცლად')</span></li>
                    </ul>
            	</div>
            </div>
        </div>
    </section>
    <!--Page Banner End-->
    
    <!--Single Blog Section Start-->
    <section id="single_blog">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                   <div class="single_blog_details">
						<div class="single_blog_img">
							<img style="height:360px" src="{{asset('public/images/news/'.$news->picture)}}" alt="" />
							<div class="single_blog_date">{{$news->created_at}}</div>
						</div>
						<h5 class="single_blog_title">{{$news->title}}</h5>
						
						<div class="text-area">
							{!!$news->body!!}
						</div>
						<div class="post_tag_media">
                              <div class="fb-share-button"  data-href="{{url('news_details',$news->id)}}" 
                                     data-layout="button_count"></div>


                                      <script src="//platform.linkedin.com/in.js" type="text/javascript"> lang: en_US</script>
<script type="IN/Share" data-url="{{url('news_details',$news->id)}}" data-counter="top"></script>
                        </div>
                   </div> 

                    <div class="fb-comments" data-width="750" data-href="{{url('news_details',$news->id)}}" data-numposts="5"></div>
                 
                   
                  
                  
                   
                </div>
                <!--Blog Page Right side bar-->
                @include('pages.rightBlog')
            </div>
        </div>
    </section>
@stop