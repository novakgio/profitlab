@extends('layout.layout')
 <meta property="og:url"           content="{{url('blog_details',$blog->id)}}" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="{{$blog->title}}" />
  <meta property="og:description"   content="{{str_limit($blog->body,20)}}"/>
  <meta property="og:image"         content="{{asset('public/images/blog/'.$blog->picture)}}" />
  <meta proprty="og:image:width"    content="800"/>
  <meta proprty="og:image:height"    content="800"/>

@section('content')
<!--Page Banner Start-->
    <section id="page_banner">
        <div class="banner_overlay">
            <div class="container">
            	<div class="row">
                    
                    <ul class="page_banner_link">
                        <li><a href="{{url('/')}}">@lang('all.მთავარი')</a>/</li>
                        
                        <li><span>@lang('all.უფრო ვრცლად')</span></li>
                    </ul>
            	</div>
            </div>
        </div>
    </section>
    <!--Page Banner End-->
    
    
    <!--Single Blog Section Start-->
    <section id="single_blog">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                   <div class="single_blog_details">
						<div class="single_blog_img">
							<img style="height:360px" src="{{asset('public/images/blog/'.$blog->picture)}}" alt="" />
							<div class="single_blog_date">{{$blog->created_at}}</div>
						</div>
						<h5 class="single_blog_title">{{$blog->title}}</h5>
						
						<div class="text-area">
							{!!$blog->body!!}
						</div>

						<div class="post_tag_media">
							 <div class="fb-share-button" 
    data-href="{{url('blog_details',$blog->id)}}" 
    data-layout="button_count">
  </div>

  <script src="//platform.linkedin.com/in.js" type="text/javascript"> lang: en_US</script>
<script type="IN/Share" data-url="{{url('blog_details',$blog->id)}}" data-counter="top"></script>
						</div>
                   </div> 
                 
                   <!-- <div class="all_comment">
                   	<h5 class="down_line_yellow commen_title">Comments  (03)</h5>
                    <div class="comment margin">
                        <img src="public/images/comment/comment_person1.png" alt="" />
                        <div class="comment_details">
                            <h6>Jonson Smith<span> 10 April 2017 at 10.00 AM</span></h6>
                            <p>Pretium. Netus a fusce. Ipsum fermentum per diam interdum euismod nam sem mi convallis urna curae;, mollis augue, sit odio eleifend dui nibh quis viverra volutpat nostra.</p>
                            <a href="#" class="replay"><i class="fa fa-reply" aria-hidden="true"></i>Replay</a>
                        </div>
                    </div>
                    <div class="comment margin reply_comment">
                        <img src="public/images/comment/comment_person2.png" alt="" />
                        <div class="comment_details reply_comment_details">
                            <h6>Jonson Smith<span> 10 April 2017 at 10.00 AM</span></h6>
                            <p>Pretium. Netus a fusce. Ipsum fermentum per diam interdum euismod nam sem mi convallis urna curae;, mollis augue, sit odio eleifend dui nibh quis viverra volutpat nostra.</p>
                            <a href="#" class="replay"><i class="fa fa-reply" aria-hidden="true"></i>Replay</a>
                        </div>
                    </div>
                    <div class="comment">
                        <img src="public/images/comment/comment_person3.png" alt="" />
                        <div class="comment_details">
                            <h6>Jonson Smith<span> 10 April 2017 at 10.00 AM</span></h6>
                            <p>Pretium. Netus a fusce. Ipsum fermentum per diam interdum euismod nam sem mi convallis urna curae;, mollis augue, sit odio eleifend dui nibh quis viverra volutpat nostra.</p>
                            <a href="#" class="replay"><i class="fa fa-reply" aria-hidden="true"></i>Replay</a>
                        </div>
                    </div>
                   </div> -->
                   <div class="fb-comments" data-width="750" data-href="{{url('blog_details',$blog->id)}}" data-numposts="5"></div>
                   
                </div>
                <!--Blog Page Right side bar-->
                @include('pages.rightBlog')
            </div>
        </div>
    </section>
@stop