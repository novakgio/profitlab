<!-- <section id="achivment">
      <div class="achievement_overlay">
        <div class="container">
          <div class="row">
            <div class="fact-counter">
                <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="achievement wow fadeIn" data-wow-duration="300ms"> <img src="images/icon/driller.png" alt="" />
                    <h2 class="counting" data-speed="3000" data-stop="100%">0</h2>
                    <h6 class="sunject">ხარისხი</h6>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="achievement wow fadeIn" data-wow-duration="300ms"> <img src="images/icon/handshake.png" alt="" />
                    <h2 class="counting" data-speed="3000" data-stop="100%">0</h2>
                    <h6 class="sunject">ნდობა</h6>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="achievement wow fadeIn" data-wow-duration="300ms"> <img src="images/icon/trophy.png" alt="" />
                    <h2 class="counting" data-speed="3000" data-stop="100">0</h2>
                    <h6 class="sunject">საპორტი</h6>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="achievement wow fadeIn" data-wow-duration="300ms"> <img src="images/icon/calendar.png" alt="" />
                    <h2 class="counting" data-speed="3000" data-stop="100">0</h2>
                    <h6 class="sunject">კმაყოფილება</h6>
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--Achivment Section End--> 
<div id="get_quote_banner">
        <div class="container">
        	<div class="row">
            	<div class="banner-quote">
                    <div class="col-md-9">
                        <div class="quote_text"><p>@lang('all.გამოიწერეთ სიახლეები და ბლოგი')</strong></p></div>
                    </div>
                    <div class="banner-btn">
                     
                        <input type="text" id="subscribe_email" class="form-control" placeholder="ელ.ფოსტა">
                        <input type="hidden" id="email_url" value="{{url('/getsubscriber')}}">
                        <a id="subscribe_button" class="btn btn-secondary">გამოწერა</a>
                        
                    </div>
                </div>

              
            </div>

        </div>
    </div>