<?php $__env->startSection('content'); ?>



<section class="content-header">
      <h1>
        სიახლეების ჩამონათვალი
       
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">ყველა სიახლე</h3>
            </div>
            <?php if(session()->has('addblockcategory')): ?>
              <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(session()->get('addblockcategory')); ?></h3>
            </div>
            <?php endif; ?>
           
            <table class="table table-striped">
                <tr>
                  
                  <th>სახელი</th>
                  <th>ტექსტი</th>
                  <th>სურათი</th>
                  
                  <th>შეცვალე</th>
                 
                  
                </tr>
                <?php foreach($news as $new): ?>


                <tr>
                  
                 

                  <td><?php echo e($new->title); ?></td>
                  <td><?php echo e(str_limit($new->body,10)); ?></td>
                  <td><img style="width:30px;height:30px;" src="<?php echo e(asset('public/images/news/'.$new->picture)); ?>"></td>
                  
                  
                  <td><a href="<?php echo e(route('admin_side.news.edit',$new->id)); ?>" type="button" class="btn btn-success">ედიტი</a></td>
                 
                
                  
                  </tr>

                
                <?php endforeach; ?>
              </table>

          </div>
        </div>
        </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>