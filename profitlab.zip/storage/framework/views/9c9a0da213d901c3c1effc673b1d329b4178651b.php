<?php $__env->startSection('content'); ?>



<section class="content-header">
      <h1>
        დაამატე ბლოგი
       
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">შეცვალე ბლოგი</h3>
            </div>
            <?php if(session()->has('addblockcategory')): ?>
              <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(session()->get('addblockcategory')); ?></h3>
            </div>
            <?php endif; ?>
            
            <?php echo e(Form::model($portfolio, array('files'=>true,'route' => array('admin_side.portfolio.update', $portfolio->id), 'method' => 'PUT', 'class' => 'form-horizontal'))); ?>

            
              <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                  <label for="exampleInputEmail1">სახელი</label>
                  

                   <?php echo e(Form::text('name',null,['class' => 'form-control'])); ?>

                </div>
                 <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
                  <style>
                      .textareaholder{
                        width:100%;
                        height:125px;
                        font-size:14px;
                        line-height: 18px;
                        border:1px solid #dddddd;
                        padding:10px;
                      }



                  </style>

                <div class="form-group<?php echo e($errors->has('body') ? ' has-error' : ''); ?>">
                  <label for="exampleInputPassword1">ტექსტი</label>
                  
                  <?php echo e(Form::textarea('body',null,['class' => 'textarea textareaholder','placeholder'=>'შენი ტექსტი'])); ?>

                </div>

                 <?php if($errors->has('body')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('body')); ?></strong>
                    </span>
                <?php endif; ?>
                <div class="form-group<?php echo e($errors->has('picture') ? ' has-error' : ''); ?>">
                  <label for="exampleInputFile">სურათი</label>
                    
                    <?php echo e(Form::file('picture')); ?>

                    
                </div>
                 <?php if($errors->has('picture')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('picture')); ?></strong>
                    </span>
                <?php endif; ?>

                <div class="form-group<?php echo e($errors->has('blog_category_id') ? ' has-error' : ''); ?>">
                  <label>აირჩიე კატეგორია</label>
                  

                  <?php echo e(Form::select('portfolio_category_id', $portfolioCategories,null,['class'=>'form-control'])); ?>

                </div>
                 <?php if($errors->has('portfolio_category_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('portfolio_category_id')); ?></strong>
                    </span>
                <?php endif; ?>


                <!-- <div class="checkbox">
                  <label>
                    <input type="checkbox"> Check me out
                  </label>
                </div> -->
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">შეცვალე</button>
              </div>
            </form>

            </form>

            <?php echo e(Form::model($portfolio, array('route' => array('admin_side.portfolio.destroy', $portfolio->id), 'method' => 'DELETE', 'class' => 'form-horizontal'))); ?>

            <?php echo e(csrf_field()); ?>

              

              <div class="box-footer">
                <button type="submit" class="btn btn-warning">წაშალე</button>
              </div>
            </form>


            
          </div>
        </div>
        </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>