<?php $__env->startSection('content'); ?>
    <!--Header Section End-->
    
    <!--Page Banner Start-->
    <section id="page_banner">
        <div class="banner_overlay">
            <div class="container">
            	<div class="row">
                    <h2 class="banner_title"><?php echo app('translator')->get('all.სიახლეები'); ?></h2>
                    <ul class="page_banner_link">
                        <li><a href="<?php echo e(url('/')); ?>"><?php echo app('translator')->get('all.მთავარი'); ?></a>/</li>
                        <li><span><?php echo app('translator')->get('all.სიახლეები'); ?></span></li>
                    </ul>
            	</div>
            </div>
        </div>
    </section>
    <!--Page Banner End-->
    
    <!--Blog Page Section Start-->
   <section id="all_blog">
        <div class="container">
            <div class="row">
                <!--All Main Blog-->
                <div class="col-md-8">
                    <div class="row">    
                         <style>

                    .blog_img a .blog_image{
                        width:370px;
                        height:220px;
                    }
                    </style>
                    <?php if(count($news)>0): ?>
                    <?php foreach($news as $new): ?>
                        <div class="col-md-6 col-sm-6">
                            <div class="blog_post">
                                <div class="blog_img"><a href="<?php echo e(url('/news_details/'.$new->id)); ?>"><img class="blog_image" src="<?php echo e(asset('public/images/news/'.$new->picture)); ?>" alt="" /></a>
                                  <div class="blog_date"><?php echo e($new->created_at->toDateTimeString()); ?></div>
                                </div>
                                <div class="blog_info"><h6 class="blog_title"><a href="<?php echo e(url('/news_details/'.$new->id)); ?>"><?php echo e($new->title); ?></a></h6>
                                 
                                 <!--  <div class="post_admin">By <a href="#">admin</a> / <a href="#">12</a> Comments / <a href="#">20</a> Views</div> -->
                                 
                                  <a class="read_more_btn" href="<?php echo e(url('/news_details/'.$new->id)); ?>"><?php echo app('translator')->get('all.სრულად ნახვა'); ?></a> 
                               </div>
                           </div>
                        </div>
                        
                       <?php endforeach; ?>
                       <?php else: ?>
                       <h1><?php echo app('translator')->get('all.სამწუხაროდ,სიახლეები არ მოიძებნა ამ კატეგორიაში'); ?></h1>
                       <?php endif; ?>

                    </div>
                    <div class="row">    
                       <?php echo $news->render(); ?>

                    </div>
                </div>
                <!--Blog Page Right side bar-->
                <?php echo $__env->make('pages.rightBlog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </section>
    <!--Blog Page Section End-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>