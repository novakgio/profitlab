<?php $__env->startSection('content'); ?>



<section class="content-header">
      <h1>
        დაამატე ბლოგი
       
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">დაამატე ბლოგის კატეგორია</h3>
            </div>
            <?php if(session()->has('addblockcategory')): ?>
              <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(session()->get('addblockcategory')); ?></h3>
            </div>
            <?php endif; ?>
           
            <table class="table table-striped">
                <tr>
                  
                  <th>სახელი</th>
                  <th>ტექსტი</th>
                  <th>სურათი</th>
                  <th>რომელ კატეგორიას ეკუთვნის</th>
                  <th>შეცვალე</th>
                 
                  
                </tr>
                <?php foreach($blogs as $blog): ?>


                <tr>
                  
                 

                  <td><?php echo e($blog->title); ?></td>
                  <td><?php echo e(str_limit($blog->body,10)); ?></td>
                  <td><img style="width:30px;height:30px;" src="<?php echo e(asset('public/images/blog/'.$blog->picture)); ?>"></td>
                  
                  <td>
                    <?php foreach($blog->getCategory as $blogCategory): ?>
                        <?php echo e($blogCategory->name); ?>,
                    <?php endforeach; ?>
                  </td>
                  <td><a href="<?php echo e(route('admin_side.blog.edit',$blog->id)); ?>" type="button" class="btn btn-success">ედიტი</a></td>
                 
                
                  
                  </tr>

                
                <?php endforeach; ?>
              </table>

          </div>
        </div>
        </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>