

<h5 class="down_line_yellow"><?php echo app('translator')->get('services.ჩვენი სერვისები'); ?></h5>
<ul>
								<li class="other_service home_icon"><a href="<?php echo e(url('/services/marketing')); ?>"><?php echo app('translator')->get('services.მარკეტინგი'); ?></a></li>
								<li class="other_service car_icon"><a href="<?php echo e(url('/services/branding')); ?>"><?php echo app('translator')->get('services.ბრენდინგი'); ?></a></li>
								<li class="other_service office_icon"><a href="<?php echo e(url('/services/peoplerelation')); ?>"><?php echo app('translator')->get('services.საზოგადოებასთან ურთიერთობა'); ?></a></li>
								<li class="other_service brush_icon"><a href="<?php echo e(url('/services/socialresponsibility')); ?>"><?php echo app('translator')->get('services.სოციალური პასუხისმგებლობა'); ?></a></li>
								<li class="other_service track_icon"><a href="<?php echo e(url('/services/corporatecommunication')); ?>"><?php echo app('translator')->get('services.კორპორაციული კომუნიკაცია'); ?></a></li>
								<li class="other_service leaf_icon"><a href="<?php echo e(url('/services/socialmarketing')); ?>"><?php echo app('translator')->get('services.სოციალური მედია მარკეტინგი'); ?></a></li>
								<li class="other_service socmarketing"><a href="<?php echo e(url('/services/digitalmarketing')); ?>"><?php echo app('translator')->get('services.ციფრული მარკეტინგი'); ?></a></li>
								<li class="other_service design"><a href="<?php echo e(url('/services/design')); ?>"><?php echo app('translator')->get('services.დიზაინი'); ?></a></li>
							</ul>


					