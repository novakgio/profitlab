<?php $__env->startSection('content'); ?>



<section class="content-header">
      <h1>
          Subscribers
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              
            </div>
            <?php if(session()->has('addblockcategory')): ?>
              <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(session()->get('addblockcategory')); ?></h3>
            </div>
            <?php endif; ?>
           
            <table class="table table-striped">
                <tr>
                  
                  <th>იმეილი</th>
                  <th>წაშალე</th>
                  
                 
                  
                </tr>
                <?php foreach($subscribers as $subscriber): ?>


                <tr>
                  
                 

                  <td><?php echo e($subscriber->email); ?></td>
                  <td><a href="<?php echo e(url('/deletesubscriber/'.$subscriber->id)); ?>" type="button" class="btn btn-success">წაშალე</a></td>
                
                  
                  </tr>

                
                <?php endforeach; ?>
              </table>

          </div>
        </div>
        </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>