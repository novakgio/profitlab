<div class="col-md-4">
                    <div class="blog_right_sidebar">
                         <?php if(!isset($news)): ?>
                        <form class="search_box margin" role="form" method="GET" action="<?php echo e(url('search_blog')); ?>">

                        
                            <input type="text" name="search_blog" placeholder="<?php echo app('translator')->get('all.მოძებნე ბლოგი სახელით'); ?>" />
                            <button type="submit" name="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                        </form>
                       
                         <div class="post_category margin">
                            <h5 class="down_line_yellow"><?php echo app('translator')->get('all.ბლოგის კატეგორიები'); ?></h5>
                            
                            <?php foreach($blogCategories as $blogCategory): ?>
                                <a class="single_category" href="<?php echo e(url('/specificBlogs/'.$blogCategory->id)); ?>"><?php echo e($blogCategory->name); ?></a>
                            <?php endforeach; ?>
                           
                           
                        </div>
                         <?php endif; ?>
                         <div class="recent_post margin">
                            <h5 class="down_line_yellow"><?php echo app('translator')->get('all.ბოლო ბლოგები'); ?></h5>
                            <?php foreach($recentBlogs as $recent): ?>
                            <div class="single_recent_post">
                                <a href="<?php echo e(url('blog_details',$recent->id)); ?>"><img src="<?php echo e(asset('public/images/blog/'.$recent->picture)); ?>" alt="" /></a>
                                <h6><a href="<?php echo e(url('blog_details',$recent->id)); ?>"><?php echo e($recent->title); ?></a></h6>
                                <p><?php echo e($recent->created_at); ?></p>
                            </div>
                            <?php endforeach; ?>
                            
                        </div>
                        <div class="archive_post margin">
                        	<h5 class="down_line_yellow"><?php echo app('translator')->get('all.წლების მიხედვით'); ?></h5>
                            <?php if(isset($news_years)): ?>
                            <?php foreach($news_years as $new_year): ?>
                                <a href="<?php echo e(url('news_year',$new_year->year)); ?>"><?php echo e($new_year->year); ?></a>
                            <?php endforeach; ?>
                            

                            <?php elseif(isset($blogs_years)): ?>
                            <?php foreach($blogs_years as $blog_year): ?>
                                <a href="<?php echo e(url('blogs_year',$blog_year->year)); ?>"><?php echo e($blog_year->year); ?></a>
                            <?php endforeach; ?>



                           
                            <?php endif; ?>

                            
                        </div>
                        <div class="photo_gallery">
                        	<h5 class="down_line_yellow"><?php echo app('translator')->get('all.უახლესი პროექტები'); ?></h5>
							<div class="sidebar-gallery">
                            <?php foreach($photo_galleries as $portfolio): ?>
								<a href="<?php echo e(url('project_details',$portfolio->id)); ?>"><img style="width:100%;height:50px;" src="<?php echo e(asset('public/images/portfolio/'.$portfolio->picture)); ?>" alt="" /></a>
                            <?php endforeach; ?>
								
							</div>
                        </div>
                    </div>
                </div>