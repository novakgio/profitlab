<?php $__env->startSection('content'); ?>



<section class="content-header">
      <h1>
        დაამატე კატეგორია
       
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">დაამატე პორტფოლიოს კატეგორია</h3>
            </div>
            <?php if(session()->has('addblockcategory')): ?>
              <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(session()->get('addblockcategory')); ?></h3>
            </div>
            <?php endif; ?>
            
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('admin_side.portfoliocategory.store')); ?>">
            <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">სახელი</label>
                  <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="ჩაწერე კატეგორია">
                </div>
                <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
               


                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
            <table class="table table-striped">
                <tr>
                  
                  <th>პორტფოლიოს კატეგორიის სახელი</th>
                  <th>წაშლა</th>
                 
                  
                </tr>
                <?php foreach($portfoliosCategories as $portfolioCategory): ?>


                <tr>
                  
                 

                  <td><?php echo e($portfolioCategory->name); ?></td>
                  
                  <td><a href="<?php echo e(route('admin_side.portfoliocategory.edit',$portfolioCategory->id)); ?>" type="button" class="btn btn-success">ედიტი</a></td>
                  
                  </tr>

                
                <?php endforeach; ?>
              </table>

          </div>
        </div>
        </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>