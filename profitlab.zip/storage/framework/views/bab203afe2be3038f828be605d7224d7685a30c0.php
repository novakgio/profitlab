<?php $__env->startSection('content'); ?>



<section class="content-header">
      <h1>
        დაამატე პორტფოლიო
       
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">შეავსე ყველა ველი რათა დაამატო</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('admin_side.portfolio.store')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                  <label for="exampleInputEmail1">სახელი</label>
                  <input type="text"  name="name" class="form-control" id="exampleInputEmail1" placeholder="დაარქვი სახელი პორტფოლიოს" value="<?php echo e(old('name')); ?>">
                </div>
                 <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>


                <div class="form-group<?php echo e($errors->has('body') ? ' has-error' : ''); ?>">
                  <label for="exampleInputPassword1">ტექსტი</label>
                  <textarea class="textarea" placeholder="შენი ტექსტი" name="body"
                            style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e(old('body')); ?></textarea>
                  
                </div>

                 <?php if($errors->has('body')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('body')); ?></strong>
                    </span>
                <?php endif; ?>
                <div class="form-group<?php echo e($errors->has('picture') ? ' has-error' : ''); ?>">
                  <label for="exampleInputFile">სურათი</label>
                  <input type="file" name="picture" id="exampleInputFile" value="<?php echo e(old('picture')); ?>">

                  
                </div>
                 <?php if($errors->has('picture')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('picture')); ?></strong>
                    </span>
                <?php endif; ?>

                <div class="form-group<?php echo e($errors->has('portfolio_category_id') ? ' has-error' : ''); ?>">
                  <label>აირჩიე კატეგორია</label>
                  <select name="portfolio_category_id" value="<?php echo e(old('portfolio_category_id')); ?>" class="form-control">
                  <?php foreach($portfolioCategories as $portfolioCategory): ?>
                    <option value="<?php echo e($portfolioCategory->id); ?>"><?php echo e($portfolioCategory->name); ?></option>
                   <?php endforeach; ?>
                  </select>
                </div>
                 <?php if($errors->has('portfolio_category_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('portfolio_category_id')); ?></strong>
                    </span>
                <?php endif; ?>


                <!-- <div class="checkbox">
                  <label>
                    <input type="checkbox"> Check me out
                  </label>
                </div> -->
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
        </div>
        </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>