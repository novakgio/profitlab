<?php
return [
    'en' => 'English',
    'ga' => 'Georgian',
];